import java.util.*;
class Main 
{
    public static void main (String[] args)
    {
        Scanner sc=new Scanner(System.in);
        int arr[][]=new int[3][3];
        int max=5;
        for(int i=0;i<3;i++)
        
        {
            for(int j=0;j<3;j++)
            {
                arr[i][j]=sc.nextInt();
            }
                
        }
        for(int i=0;i<3;i++)
        {
        for(int j=0;j<3;j++)
        {
           if(max==arr[i][j]);
        }
        
        }
        System.out.print("Element Found="+max);
        }
}
   
