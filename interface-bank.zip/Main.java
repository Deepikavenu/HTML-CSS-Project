/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
interface A {
    int account_num = 12345;
    String name = "Raga";
}
interface B extends A
{
   void add();
    
}
class AB implements B{
    public void add(){
        System.out.println("Add the account");
    }
}

 class Main
{
	public static void main(String[] args) {
	    AB obj = new AB();
	    //obj.add();
	    int B = 12456;
	   try{
	        if(A.account_num == B)
	        System.out.println("crt account num");
	        else
	        throw new Exception();
	    }
	    catch(Exception e){
		System.out.println("Account number can't be changed");
	    }
	}
}
