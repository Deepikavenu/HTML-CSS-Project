import java.util.*;
class Main
{
    public static void main(String[] args)
    {
        Scanner sc=new Scanner(System.in);
        int n=sc.nextInt();
        int sum=0,rev=0;
        while(n!=0)
        {
           int digit=n%10;
           sum+=digit;
           n/=10;
        }
        int count=0;
        while(sum!=0)
        {
            int digit=sum%10;
           rev=(rev*10)+digit;
           count++;
           sum/=10;
        }
        System.out.print(count);
    }
}