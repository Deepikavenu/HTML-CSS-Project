   import java.util.*;
   class Main
   {
       public static void main(String[] args) {
        Scanner sc = new Scanner(System.in); // Initialize the scanner
        int size = sc.nextInt(); // Read the size of the array
        int[] arr = new int[size]; // Create the array of given size

        // Read the array elements from user input
        for (int i = 0; i < arr.length; i++) {
            arr[i] = sc.nextInt(); // Assign each element to the array
        }

        // Sort the entire array
        Arrays.sort(arr); // Sort the array in ascending order

        // Print the sorted array
        System.out.print("Sorted array: ");
        for (int i = 0; i < arr.length; i++) {
            System.out.print(arr[i] + " "); // Print each element
        }
    }
}
