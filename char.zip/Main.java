import java.util.*;

class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        String str = sc.nextLine();
        char ch[] = str.toCharArray();
        char temp;
        int i = 0, j = str.length() - 1;

        while (i < j) {
            while (i < j && !((ch[i] >= 'A' && ch[i] <= 'Z') || (ch[i] >= 'a' && ch[i] <= 'z') || (ch[i] >= '0' && ch[i] <= '9')))
                i++;
            while (i < j && !((ch[j] >= 'A' && ch[j] <= 'Z') || (ch[j] >= 'a' && ch[j] <= 'z') || (ch[j] >= '0' && ch[j] <= '9')))
                j--;
            if (i < j) {
                temp = ch[i];
                ch[i] = ch[j];
                ch[j] = temp;
                i++;
                j--;
            }
        }

        for (i = 0; i < str.length(); i++) {
            System.out.print(ch[i]);
        }
    }
}

   